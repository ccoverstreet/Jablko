# Jablko Weather

If you want to install the latest working version, run

`./jpm install ccoverstreet/Jablko-Weather master weather`

or replace master with v1.1.0 or similar tag
