# Jablko Interface Status

Provides a dashboard summary of Jablko performance characteristics.

If you want to install the latest working version, run
`./jpm install ccoverstreet/Jablko-Interface-Status master interface_status`
or replace master with v1.1.0 or similar tag
