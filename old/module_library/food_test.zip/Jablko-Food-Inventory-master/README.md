# Jablko Food Inventory

If you want to install the latest working version, run 

`./jpm install ccoverstreet/Jablko-Food-Inventory master food_inventory`

or replace `master` with the desired version tag
